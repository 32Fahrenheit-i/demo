package com.example.demo.Repository;

public class UserRepository {
}
