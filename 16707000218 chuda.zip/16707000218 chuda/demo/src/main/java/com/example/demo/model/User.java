package com.example.demo.model;

public class User {
}